(function ($) {
  'use strict';

  // Summernote
  $('.summernote').summernote();

  $('.bootstrap-wysiwyg').wysihtml5({
    toolbar: {
      fa: true
    }
  });

})(jQuery);
