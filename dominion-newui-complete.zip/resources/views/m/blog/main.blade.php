@include('/m/blog/partials._head')

@include('/m/blog/partials._messages')

@yield('content')

@include('/m/blog/partials._footer')

