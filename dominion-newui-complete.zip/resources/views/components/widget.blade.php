<div class="widget {{ isset($bgcolor) ? $bgcolor : '' }}">
	{!! isset($icon) ? $icon : '' !!}
	<div class="overflow-hidden">
  	<span class="widget-title">{!! $title !!}</span>
  	<span class="widget-subtitle">{!! $subtitle !!}</span>
	</div>
</div>