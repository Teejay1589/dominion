<header class="header navbar">
  <div class="brand visible-xs">
    <!-- toggle offscreen menu -->
    <div class="toggle-offscreen">
      <a href="#" class="hamburger-icon visible-xs" data-toggle="offscreen" data-move="ltr">
        <span></span>
        <span></span>
        <span></span>
      </a>
    </div>
    <!-- /toggle offscreen menu -->

    <!-- logo -->
    <div class="brand-logo">
      <a href="javascript:;">
        <strong>DOMINION MC</strong>
        
      </a>
    </div>
    <!-- /logo -->

    <!-- toggle chat sidebar small screen-->
    
    <!-- /toggle chat sidebar small screen-->
  </div>

  <?php if( View::hasSection('title') ): ?>
	  <ul class="nav navbar-nav hidden-xs">
	    <li>
	      <p class="navbar-text">
	        <?php echo $__env->yieldContent('title'); ?>
	      </p>
	    </li>
	  </ul>
  <?php endif; ?>

  <?php if(auth()->guard('admin')->check()): ?>
    <ul class="nav navbar-nav navbar-right hidden-xs">
      

      <li>
        <a href="javascript:;" data-toggle="dropdown">
          <img src="<?php echo e(asset('urban/images/avatar.jpg')); ?>" class="header-avatar img-circle ml10" alt="user" title="user">
          <span class=""><?php echo e(Auth::guard('admin')->user()->first_name); ?> <?php echo e(Auth::guard('admin')->user()->last_name[0]); ?>.</span>
        </a>
        <ul class="dropdown-menu">
          <li>
            <a href="<?php echo e(url('/')); ?>">Home</a>
          </li>
          <li>
            <a href="<?php echo e(url('/m/profile')); ?>">Profile</a>
          </li>
          <li>
            <a href="javascript:;">Settings</a>
          </li>
          <li>
            <a rel="nofollow" class="dropdown-item" href="<?php echo e(route('m.logout')); ?>"
              onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
              Logout
            </a>

            <form id="logout-form" action="<?php echo e(route('m.logout')); ?>" method="POST"
                  style="display: none;">
                <?php echo e(csrf_field()); ?>

            </form>
          </li>
        </ul>
      </li>

	    
    </ul>
  <?php endif; ?>
</header>
