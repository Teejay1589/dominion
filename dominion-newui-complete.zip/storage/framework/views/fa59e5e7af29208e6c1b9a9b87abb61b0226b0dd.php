<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('page_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <form role="form" action="<?php echo e(route('m.login')); ?>" class="form-layout" method="POST">
    <?php echo e(csrf_field()); ?>


    <div class="text-center mb15">
      <h3><?php echo e(env('APP_FULLNAME', 'DOMINION MEDICAL CENTER')); ?></h3>
      
    </div>
    <p class="text-center mb30">Welcome to <?php echo e(env('APP_FULLNAME', 'DOMINION MEDICAL CENTER')); ?>. Please Login to your account</p>

    <div class="form-inputs">
      <div class="form-group">
        <label>Email</label>
        <input type="email" class="form-control input-lg" placeholder="Email Address" name="email" required>
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" class="form-control input-lg" placeholder="Password" name="password" required>
      </div>
    </div>

    <button class="btn btn-success btn-block btn-lg mb15" type="submit">Login</button>

    <p>
      <a href="<?php echo e(route('m.register')); ?>">Register Here</a> &bull;
      <a href="javascript:;">Forgot your password?</a>
    </p>
  </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>