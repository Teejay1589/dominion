<?php $__env->startSection('title', $page->title); ?>

<?php $__env->startSection('page_styles'); ?>
    <?php if( count($patients) > 0 ): ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('js/datatables/datatables.min.css')); ?>">
        <style type="text/css">
            .dataTables_wrapper .row {
                width: 100%;
            }
        </style>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section>
        <div class="container-fluid">
        	<div>
        		<a href="#modal-create" class="btn btn-link btn-block" data-toggle="modal">Create Patient</a>
	        	<?php echo $__env->make('forms.patients-create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        	</div>

        	<div class="clearfix"></div>
        	<br>

            <?php echo $__env->make('tables.patients', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
    <?php if( count($patients) > 0 ): ?>
        <script type="text/javascript" src="<?php echo e(asset('js/datatables/datatables.min.js')); ?>"></script>
        <script type="text/javascript">
            $(".table").DataTable({
                "pageLength": 10
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>