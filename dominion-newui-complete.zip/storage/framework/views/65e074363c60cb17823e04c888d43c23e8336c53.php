<!doctype html>
<html class="no-js" lang="<?php echo e(app()->getLocale()); ?>">
<head>
  <meta charset="utf-8">
  <meta name="description" content="<?php echo e(env('APP_FULLNAME', 'DOMINION MEDICAL CENTER')); ?> is a Hospital Website.">
  <meta name="viewport" content="width=device-width">
  <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="author" content="Yinka, Tunji Oyeniran">

  <?php if( View::hasSection('title') ): ?>
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(env('APP_FULLNAME', 'DOMINION MEDICAL CENTER')); ?> Management</title>
  <?php else: ?>
    <title><?php echo e(env('APP_FULLNAME', 'DOMINION MEDICAL CENTER')); ?></title>
  <?php endif; ?>

  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  
  <link rel="stylesheet" href="<?php echo e(asset('urban/vendor/bootstrap/dist/css/bootstrap.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('urban/vendor/perfect-scrollbar/css/perfect-scrollbar.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('urban/styles/roboto.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('urban/styles/font-awesome.css')); ?>">
  
  
  <link rel="stylesheet" href="<?php echo e(asset('urban/styles/animate.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('urban/styles/urban.css')); ?>">
  
  <style type="text/css">
    /**:not(.circle-icon):not(.status) {
      border-radius: 0 !important;
    }*/
    #main-nav li.active a, #main-nav li a:hover {
      border-bottom: 2px solid #0099cc;
    }
    .list-group-item.active {
      background: #0099cc;
      border-color: #0099cc;
    }
    .list-group-item.active:hover {
      background: #007399;
      border-color: #007399;
    }
    .table-wrapper {
      overflow-x: auto;
    }
    textarea {
      resize: vertical;
    }
    .main-content {
      min-height: 95vh;
    }
  </style>

  
  <?php if( View::hasSection('page_styles') ): ?>
      <?php echo $__env->yieldContent('page_styles'); ?>
  <?php endif; ?>
</head>

<body>
  <div id="app">
    <!-- quick launch panel -->

    <!-- /quick launch panel -->

    <div class="app layout-fixed-header">

      <!-- sidebar panel -->
      <?php echo $__env->make('shared.admin-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!-- /sidebar panel -->

      <!-- content panel -->
      <div class="main-panel">

        <!-- top header -->
        <?php echo $__env->make('shared.admin-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- /top header -->


        <!-- main area -->
        <div class="main-content" style="margin-bottom: 0; padding-left: 10px; padding-right: 10px;">
          <?php echo $__env->make('shared.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?><br>
          <?php echo $__env->yieldContent('content'); ?>
        </div>
        <!-- /main area -->
      </div>
      <!-- /content panel -->

      <!-- bottom footer -->
      <?php echo $__env->make('shared.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!-- /bottom footer -->

      <!-- chat -->
      
      <!-- /chat -->
    </div>
  </div>

  
  
  <script src="<?php echo e(asset('urban/vendor/jquery/dist/jquery.js')); ?>"></script>
  <script src="<?php echo e(asset('urban/vendor/bootstrap/dist/js/bootstrap.js')); ?>"></script>
  <script src="<?php echo e(asset('urban/vendor/jquery.easing/jquery.easing.js')); ?>"></script>
  
  
  
  <script src="<?php echo e(asset('urban/vendor/perfect-scrollbar/js/perfect-scrollbar.jquery.js')); ?>"></script>
  
  
  
  
  
  <script src="<?php echo e(asset('urban/scripts/ui/toggle.js')); ?>"></script>
  
  
  <script type="text/javascript">
    // Confirm Action
    $('.confirm-action').click(function(e) {
      var ans = confirm('Are you sureee?');
      if(ans) {
      } else {
        e.preventDefault();
      }
    });

    // Sidebar Toggle FIX
    $('a[data-toggle="offscreen"]').click(function(e) {
      $('.app').toggleClass('offscreen');
      $('.app').toggleClass('move-left');
    });
  </script>

  
  <?php if( View::hasSection('page_scripts') ): ?>
      <?php echo $__env->yieldContent('page_scripts'); ?>
  <?php endif; ?>
</body>

</html>