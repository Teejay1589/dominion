<div class="sidebar-panel offscreen-left">
  <div class="brand">
    <!-- logo -->
    <div class="brand-logo pull-left">
      <a href="<?php echo e(url('/')); ?>">
        <strong>DOMINION MC</strong>
        
      </a>
    </div>
    <!-- /logo -->

    <!-- toggle small sidebar menu -->
    <a href="javascript:;" class="toggle-sidebar hidden-xs hamburger-icon v3" data-toggle="layout-small-menu">
      <span></span>
	      <span></span>
	      <span></span>
	      <span></span>
    </a>
    <!-- /toggle small sidebar menu -->
  </div>

  <!-- main navigation -->
  <nav role="navigation">
    <ul class="nav">

    	<li class="text-center">
        <img src="<?php echo e(asset('urban/images/avatar.jpg')); ?>" class="header-avatar img-circle ml10" alt="avata" title="user" width="50px" height="50px">
        <p class="" style="color: #fff; padding: 5px; margin: 0;"><?php echo e(Auth::guard('admin')->user()->first_name); ?> <?php echo e(Auth::guard('admin')->user()->last_name); ?></p>
        <span class="bg-white" style="padding: 2px 5px; margin: 0;"><?php echo e(Auth::guard('admin')->user()->role->name); ?></span>
        <div class="clearfix"></div>
        <br>
      </li>

      <!-- dashboard -->
      <li class="<?php echo e(isset($page) && $page->view == 'm.home' ? 'active' : ''); ?>">
        <a href="<?php echo e(url('/m/home')); ?>">
          <i class="fa fa-desktop"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <!-- /dashboard -->

      <!-- profile -->
      <li class="<?php echo e(isset($page) && $page->view == 'm.profile' ? 'active' : ''); ?>">
        <a href="<?php echo e(url('/m/profile')); ?>">
          <i class="fa fa-user-md"></i>
          <span>Profile</span>
        </a>
      </li>
      <!-- /profile -->

      <!-- patients -->
      <li class="<?php echo e(isset($page) && $page->view == 'm.patients' ? 'active' : ''); ?>">
        <a href="<?php echo e(url('/m/patients')); ?>">
          <i class="fa fa-users"></i>
          <span>Patients</span>
        </a>
      </li>
      <!-- /patients -->

      <!-- patient_visits -->
      <li class="<?php echo e(isset($page) && $page->view == 'm.patient_visits' ? 'active' : ''); ?>">
        <a href="<?php echo e(url('/m/patient/0/visits')); ?>">
          <i class="fa fa-child"></i>
          <span>Patient Visits</span>
        </a>
      </li>
      <!-- /patient_visits -->

      <!-- visits -->
      <li class="<?php echo e(isset($page) && $page->view == 'm.cases' ? 'active' : ''); ?>">
        <a href="<?php echo e(url('/m/cases')); ?>">
          <i class="fa fa-child"></i>
          <span>All Visits</span>
        </a>
      </li>
      <!-- /visits -->

      <!-- surgeries -->
      <li class="<?php echo e(isset($page) && $page->view == 'm.surgeries' ? 'active' : ''); ?>">
        <a href="<?php echo e(url('/m/surgeries')); ?>">
          <i class="fa fa-stethoscope"></i>
          <span>All Surgeries</span>
        </a>
      </li>
      <!-- /surgeries -->

      <!-- surgery_names -->
      <li class="<?php echo e(isset($page) && $page->view == 'm.surgery_names' ? 'active' : ''); ?>">
        <a href="<?php echo e(url('/m/surgery_names')); ?>">
          <i class="fa fa-bolt"></i>
          <span>Surgery Names</span>
        </a>
      </li>
      <!-- /surgery_names -->

      <!-- blog_posts -->
      <li class="<?php echo e(isset($page) && $page->view == 'm.blog.posts' ? 'active' : ''); ?>">
        <a href="<?php echo e(url('/m/blog/posts')); ?>">
          <i class="fa fa-paragraph"></i>
          <span>Blog Posts</span>
        </a>
      </li>
      <!-- /blog_posts -->

    </ul>
  </nav>
  <!-- /main navigation -->
</div>
