<footer class="content-footer" style="padding-left: 15px; position: relative;">
  <nav class="footer-right">
    <ul class="nav">
      <li>
        <a href="javascript:;">Feedback</a>
      </li>
      <li>
        <a href="javascript:;" class="scroll-up">
          <i class="fa fa-angle-up"></i>
        </a>
      </li>
    </ul>
  </nav>

  <nav class="footer-left">
    <ul class="nav">
      <li>
        <a href="javascript:;"><span>DOMINION</span></a>
      </li>
      <li>
        <a href="javascript:;"><i class="fa fa-copyright"></i> 2018. All rights reserved</a>
      </li>
      <li>
        <a href="javascript:;">Terms</a>
      </li>
      <li>
        <a href="javascript:;">
            Privacy Policy
        </a>
      </li>
    </ul>
  </nav>
</footer>