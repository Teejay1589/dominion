<!doctype html>
<html class="no-js" lang="<?php echo e(app()->getLocale()); ?>">
<head>
  <meta charset="utf-8">
  <meta name="description" content="<?php echo e(env('APP_FULLNAME', 'DOMINION MEDICAL CENTER')); ?> is a Hospital Website.">
  <meta name="viewport" content="width=device-width">
  <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="author" content="Yinka, Tunji Oyeniran">

  <?php if( View::hasSection('title') ): ?>
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(env('APP_FULLNAME', 'DOMINION MEDICAL CENTER')); ?> Management</title>
  <?php else: ?>
    <title><?php echo e(env('APP_FULLNAME', 'DOMINION MEDICAL CENTER')); ?></title>
  <?php endif; ?>

  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  
  <link rel="stylesheet" href="<?php echo e(asset('urban/vendor/bootstrap/dist/css/bootstrap.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(asset('urban/styles/roboto.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('urban/styles/font-awesome.css')); ?>">
  
  
  <link rel="stylesheet" href="<?php echo e(asset('urban/styles/animate.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('urban/styles/urban.css')); ?>">
  

  
  <?php if( View::hasSection('page_styles') ): ?>
      <?php echo $__env->yieldContent('page_styles'); ?>
  <?php endif; ?>
</head>
<body class="bg-white">

  <div class="app layout-fixed-header bg-white usersession">
    <div class="full-height">
      <div class="center-wrapper">
        <div class="center-content">
          <div class="row no-margin">
            <div class="col-xs-12 col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">
              <?php echo $__env->make('shared.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php echo $__env->yieldContent('content'); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  
  
  <script src="<?php echo e(asset('urban/vendor/jquery/dist/jquery.js')); ?>"></script>
  <script src="<?php echo e(asset('urban/vendor/bootstrap/dist/js/bootstrap.js')); ?>"></script>
  <script src="<?php echo e(asset('urban/vendor/jquery.easing/jquery.easing.js')); ?>"></script>
  
  
  
  
  
  
  
  
  
  <script src="<?php echo e(asset('urban/scripts/ui/toggle.js')); ?>"></script>
  
  

 	
  <?php if( View::hasSection('page_scripts') ): ?>
      <?php echo $__env->yieldContent('page_scripts'); ?>
  <?php endif; ?>
</body>
</html>
