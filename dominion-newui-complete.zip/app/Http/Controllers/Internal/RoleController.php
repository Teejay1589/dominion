<?php

namespace App\Http\Controllers\Internal;

use Illuminate\Http\Request;

class RoleController extends InternalControl
{
    //
}
