<!-- Main Navbar-->
<header class="header">
    <nav class="navbar">
        <!-- Search Box-->
        <div class="search-box">
            <button class="dismiss"><i class="icon-close"></i></button>
            <form id="searchForm" action="#" role="search">
                <input type="search" placeholder="What are you looking for..." class="form-control">
            </form>
        </div>
        <div class="container-fluid">
            <div class="navbar-holder d-flex align-items-center justify-content-between">
                <!-- Navbar Header-->
                <div class="navbar-header">
                    <!-- Navbar Brand --><a href="<?php echo e(url('/')); ?>" class="navbar-brand">
                        <div class="brand-text brand-big"><span>Dominion</span> <strong>HMS</strong></div>
                        <div class="brand-text brand-small"><strong>DHMS</strong></div></a>
                    <!-- Toggle Button--><a id="toggle-btn" href="#" class="menu-btn active"><span></span><span></span><span></span></a>
                </div>
                <!-- Navbar Menu -->
                <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">
                    <!-- Search-->
                    

                    <!-- Notifications-->
                    
                    <!-- Messages-->
                    

                    <!-- Logout    -->
                    

                    <li class="nav-item dropdown">
                        <a data-target="#" href="#" data-toggle="dropdown" aria-haspopup="true"
                           aria-expanded="false" class="nav-link language dropdown-toggle">
                            <span class="d-none d-sm-inline-block">
                                <?php echo e(Auth::user()->first_name . " " . Auth::user()->last_name); ?></span>
                        </a>
                        <ul aria-labelledby="languages" class="dropdown-menu">
                            <li>
                                <a rel="nofollow" class="dropdown-item" href="<?php echo e(url('/home')); ?>">
                                    Dashboard
                                </a>
                            </li>
                            <li>
                                <a rel="nofollow" class="dropdown-item" href="<?php echo e(url('/profile')); ?>">
                                    Profile
                                </a>
                            </li>
                            <li>
                                <a rel="nofollow" class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                      style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>