<?php $__env->startSection('page_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section>
        <div class="container-fluid">
            <div id="update-profile" class="card" style="width: 100%;">
                <div class="card-close">
                    <div class="dropdown">
                        <button type="button" id="closeCard1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-ellipsis-v"></i></button>
                        <div aria-labelledby="closeCard1" class="dropdown-menu dropdown-menu-right has-shadow"><a href="#" class="dropdown-item remove"> <i class="fa fa-times"></i>Close</a><a href="#" class="dropdown-item edit"> <i class="fa fa-gear"></i>Edit</a></div>
                    </div>
                </div>
                <div class="card-header">
                    <div class="card-title">Update Profile Form</div>
                </div>
                <div class="card-body">
                    <form class="" action="<?php echo e(url('/profile/update')); ?>" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <?php echo e(csrf_field()); ?>

                        </div>

                        <div class="row">
                            <div class="col-lg-6 col-xs-12">
                                <div class="form-group">
                                    <label class="form-control-label">First Name: <span class="text-danger">*</span></label>
                                    <input class="form-control" placeholder="Your First Name" type="text" name="first_name" value="<?php echo e(old('first_name', Auth::user()->first_name)); ?>" required>
                                </div>
                            </div>
                            <div class="col-lg-6 col-xs-12">
                                <div class="form-group">
                                    <label class="form-control-label">Last Name: <span class="text-danger">*</span></label>
                                    <input class="form-control" placeholder="Your Last Name" type="text" name="last_name" value="<?php echo e(old('last_name', Auth::user()->last_name)); ?>" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-6 col-xs-12">
                                <div class="form-group">
                                    <label class="form-control-label">Email: <span class="text-danger">*</span></label>
                                    <input class="form-control" placeholder="Your Email" type="email" name="email" value="<?php echo e(old('email', Auth::user()->email)); ?>" required>
                                </div>
                            </div>
                            <div class="col-lg-6 col-xs-12">
                                <div class="form-group">
                                    <label class="form-control-label">Phone Number: <span class="text-danger">*</span></label>
                                    <input class="form-control" placeholder="Your Phone Number" type="tel" name="phone" value="<?php echo e(old('phone', Auth::user()->phone)); ?>" required>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-control-label">Gender: <span class="text-danger">*</span></label>
                            <select name="gender" class="form-control" required>
                                <option value="MALE" <?php echo e(old('gender', Auth::user()->gender) == 'MALE' ? 'selected' : ''); ?>>MALE</option>
                                <option value="FEMALE" <?php echo e(old('gender', Auth::user()->gender) == 'FEMALE' ? 'selected' : ''); ?>>FEMALE</option>
                            </select>
                        </div>

                        

                        <div class="text-right">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="clearfix"></div>
            <br>

            <div id="change-password" class="card" style="width: 100%;">
                <div class="card-close">
                    <div class="dropdown">
                        <button type="button" id="closeCard1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-ellipsis-v"></i></button>
                        <div aria-labelledby="closeCard1" class="dropdown-menu dropdown-menu-right has-shadow"><a href="#" class="dropdown-item remove"> <i class="fa fa-times"></i>Close</a><a href="#" class="dropdown-item edit"> <i class="fa fa-gear"></i>Edit</a></div>
                    </div>
                </div>
                <div class="card-header">
                    <div class="card-title">Change Password Form</div>
                </div>
                <div class="card-body">
                    <form class="" action="<?php echo e(url('/password/change')); ?>" method="POST">
                        <div class="form-group">
                            <?php echo e(csrf_field()); ?>

                        </div>

                        <div class="form-group">
                            <label for="current_password" class="form-control-label">Current Password: <span class="text-danger">*</span></label>
                            <input class="form-control" placeholder="Your Current Password" type="password" name="current_password" required>
                        </div>

                        <div class="form-group" class="form-control-label">
                            <label for="new_password" class="form-control-label">New Password: <span class="text-danger">*</span></label>
                            <input class="form-control" placeholder="Your New Password" type="password" name="new_password" required>
                        </div>

                        <div class="form-group" class="form-control-label">
                            <label for="new_password_confirmation" class="form-control-label">Confirm New Password: <span class="text-danger">*</span></label>
                            <input class="form-control" placeholder="Confirm New Password" type="password" name="new_password_confirmation" required>
                        </div>

                        <div class="text-right">
                            <button type="submit" class="btn btn-primary">Change</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.patient', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>