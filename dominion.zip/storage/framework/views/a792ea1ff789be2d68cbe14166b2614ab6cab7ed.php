<div class="modal fade" id="modal-view-<?php echo e($active_object->id); ?>">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Viewing Patient: <small><?php echo e($active_object->first_name." ".$active_object->last_name); ?></small></h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					<span class="sr-only">Close</span>
				</button>
			</div>
			<div class="modal-body">

				<div class="h5">Patient Details</div>
				<hr>
				<dl>
					<dt>First Name</dt>
					<dd><?php echo e($active_object->first_name); ?></dd>
					<dt>Last Name</dt>
					<dd><?php echo e($active_object->last_name); ?></dd>
					<dt>Gender</dt>
					<dd><?php echo e($active_object->gender); ?></dd>
					<dt>Blood Group</dt>
					<dd><?php echo e($active_object->blood_group); ?></dd>
					<dt>Weight</dt>
					<dd><?php echo e($active_object->weight); ?></dd>
					<dt>Height</dt>
					<dd><?php echo e($active_object->height); ?></dd>
				</dl>

				<div class="clearfix"></div>
				<br>

				<div class="h5">Contact Details</div>
				<hr>
				<dl>
					<dt>Email</dt>
					<dd><?php echo e($active_object->email); ?></dd>
					<dt>Phone Number</dt>
					<dd><?php echo e($active_object->phone); ?></dd>
				</dl>

				<div class="clearfix"></div>
				<br>

				<div class="h5">Next of Kin Details</div>
				<hr>
				<dl>
					<dt>Next of Kin</dt>
					<dd><?php echo e($active_object->next_of_kin); ?></dd>
					<dt>Next of Kin Telephone</dt>
					<dd><?php echo e($active_object->next_of_kin_telephone); ?></dd>
				</dl>

				<div class="clearfix"></div>
				<br>

				<div class="h5">Actions</div>
				<hr>
				<dl>
					<dt>Password</dt>
					<dd><a href="<?php echo e(url('/m/patients/password/reset/'.$active_object->id)); ?>">reset patient password</a></dd>
				</dl>

			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
</div>