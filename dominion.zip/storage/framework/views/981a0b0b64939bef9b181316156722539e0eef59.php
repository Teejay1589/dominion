<!DOCTYPE html>
<html lang="en">
<head>
    <title>Dominion Medical Centre</title>
    <!-- custom-theme -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <script type="application/x-javascript"> addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);
        function hideURLbar() {
            window.scrollTo(0, 1);
        } </script>
    <!-- //custom-theme -->
    <script type="text/javascript" src="<?php echo e(asset('js/jquery-1.11.1.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
    <!-- stylesheet -->
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" media="all"/>
    <link href="<?php echo e(asset('css/easy-responsive-tabs.css')); ?>" rel='stylesheet' type='text/css'/>
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css" media="all"/>
    <link href="<?php echo e(asset('css/gallery.css')); ?>" rel="stylesheet" type="text/css" media="all"/> <!-- gallery css -->
    <!-- //stylesheet -->
    <!-- online fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
    <link href="//fonts.googleapis.com/css?family=Titillium+Web:200,200i,300,300i,400,400i,600,600i,700,700i,900"
          rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
    <!-- //online fonts -->
    <!-- font-awesome-icons -->
    <link href="<?php echo e(asset('css/font-awesome.css')); ?>" type="text/css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fontastic.css')); ?>">
    <!-- //font-awesome-icons -->
    <script src="<?php echo e(asset('js/modernizr.custom.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/modernizr.custom.79639.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/custom.css')); ?>"/>
    <!-- for smooth scrolling -->
    <script type="text/javascript" src="<?php echo e(asset('js/move-top.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/easing.js')); ?>"></script>
    <script type="text/javascript">
        jQuery(document).ready(function ($) {
            $(".scroll").click(function (event) {
                event.preventDefault();
                $('html,body').animate({scrollTop: $(this.hash).offset().top}, 1000);
            });
        });
    </script>
    <!-- //for smooth scrolling -->
</head>
<body>

<div class="header-top">
    <div class="container">
        <div class="header-top-left">
            <ul id="m_nav_list" class="m_nav menu__list">
                <li class="m_nav_item menu__item menu__item--current" id="m_nav_item_1"><a href="index.html"
                                                                                           class="menu__link">Home </a>
                </li>
                <li class="m_nav_item menu__item" id="moble_nav_item_2"><a href="#about" class="menu__link">About
                        Us </a></li>
                <li class="m_nav_item menu__item" id="moble_nav_item_3"><a href="#services"
                                                                           class="menu__link">Services</a></li>
                <li class="m_nav_item menu__item" id="moble_nav_item_4"><a href="#team" class="menu__link">Team</a></li>
            </ul>
        </div>

        <a href="<?php echo e(url('/login')); ?>">
            <div class="header-top-right">
                <p>Our Patient? Login</p>
            </div>
        </a>
        <a href="<?php echo e(url('/newBook')); ?>" data-toggle="modal" data-target="#myModal1">
            <div class="header-top-right mg-right">
                <p class="appoint">New Patient? Book An Appointment</p>
            </div>
        </a>
        <div class="clearfix"></div>
    </div>
</div>
<div class="header">
    <div class="container">
        <div class="logo">
            <a href="<?php echo e(url('/')); ?>">Dominion <span>Medical Center</span></a>
        </div>


        <div class="header-right-info pull-right">
            <ul>
                <li>
                    <div class="single-header-right-info">
                        <div class="icon-box"><i class="fa fa-map-marker"></i></div>
                        <div class="text-box">
                            <h5>4 Nova Road</h5>
                            <p>Ado-Ekiti, Ekiti State.</p>

                        </div>
                    </div>
                </li>
                <li>
                    <div class="single-header-right-info">
                        <div class="icon-box"><i class="fa fa-phone"></i></div>
                        <div class="text-box">
                            <h5>+234(0)8177433899</h5>
                            <p>Call In Today</p>

                        </div>
                    </div>
                </li>
                <li>
                    <div class="single-header-right-info">
                        <div class="icon-box"><i class="fa fa-clock-o"></i></div>
                        <div class="text-box">
                            <h5>Mon - Sat 24hrs service</h5>
                            <p>Sunday 24hrs service</p>

                        </div>
                    </div>
                </li>
            </ul>
        </div>


        <div class="clearfix"></div>
    </div>


</div>
<!-- //header -->


<div class="agileits_main">
    <!-- menu -->
    <script type="text/javascript" src="<?php echo e(asset('js/main.js')); ?>"></script>
    <!-- //menu -->
    <!--// header -->
    <!-- banner -->
    <div class="w3_banner">
        <div class="container">
            <div class="slider">
                <div class="callbacks_container">
                    <ul class="rslides callbacks callbacks1" id="slider4">
                        <li>
                            <div class="banner_text_w3layouts">
                                <h3>Health Is The Only Wealth We Know</h3>
                                <p>Dr. Awoleke J. O.</p>
                            </div>
                        </li>
                        <li>
                            <div class="banner_text_w3layouts">
                                <h3>Tellus nec enim tempus Nam </h3>
                                <p>Nam tellus nec enim tempus</p>
                            </div>
                        </li>
                        <li>
                            <div class="banner_text_w3layouts">
                                <h3>Nam tellus nec enim tempus </h3>
                                <p>Nam tellus nec enim tempus</p>
                            </div>
                        </li>
                    </ul>
                </div>
                <script src="<?php echo e(asset('js/responsiveslides.js')); ?>"></script>
                <script>
                    // You can also use "$(window).load(function() {"
                    $(function () {
                        // Slideshow 4
                        $("#slider4").responsiveSlides({
                            auto: false,
                            pager: true,
                            nav: true,
                            speed: 500,
                            namespace: "callbacks",
                            before: function () {
                                $('.events').append("<li>before event fired.</li>");
                            },
                            after: function () {
                                $('.events').append("<li>after event fired.</li>");
                            }
                        });

                    });
                </script>
            </div>
        </div>
    </div>
</div>
<!-- //banner -->
<!-- about -->
<div class="jarallax w3ls-about w3ls-section " id="about">
    <div class="container">
        <h3 class="h3-w3l">about us</h3>
        <div class="about-head text-center">
            <div class="col-md-4 col-sm-4 col-xs-6 wthree-s1 ">
                <span class="fa fa-medkit sicon" aria-hidden="true"></span>
                <h4>Healthline</h4>
                <p>Our Intensive Care Unit also known as the Critical Care Unit is a special department of the hospital
                    where we can provide around the clock continuous monitoring of our more seriously ill patients.</p>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-6 wthree-s1  s1  s1-active">
                <span class="fa fa-user-md sicon" aria-hidden="true"></span>
                <h4>Hospitality</h4>
                <p>Our Intensive Care Unit also known as the Critical Care Unit is a special department of the hospital
                    where we can provide around the clock continuous monitoring of our more seriously ill patients.</p>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-6 wthree-s1">
                <span class="fa fa-ambulance sicon" aria-hidden="true"></span>
                <h4>Humaneness</h4>
                <p>Our Intensive Care Unit also known as the Critical Care Unit is a special department of the hospital
                    where we can provide around the clock continuous monitoring of our more seriously ill patients.</p>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<!-- //about -->

<div class="jarallax w3ls-services w3ls-section" id="services">
    <div class="container">
        <h3 class="h3-w3l">services</h3>
        <div class="services-head text-center">
            <h4>the skill to heal. the spirit to care</h4>
            <p>Our Intensive Care Unit also known as the Critical Care Unit is a special department of the hospital
                where we can provide around the clock continuous monitoring of our more seriously ill patients.</p>
        </div>
    </div>
    <div class="wthree-services-bottom">
        <div class="container">
            <div class="col-md-3 col-sm-3 col-xs-6 wthree-sb1 ">
                <span class="fa fa-plus-circle sicon" aria-hidden="true"></span>
                <span class="num">01</span><h4>Internal Medicine</h4>
                <p>We provide the most essential health values with the best of Internal Medication</p>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6 wthree-sb1  sb1">
                <span class="fa fa-star-o sicon" aria-hidden="true"></span>
                <span class="num">02</span><h4>Obstetrics & Gynaecology</h4>
                <p>We provide the most essential health values with the best of Obstetrics & Gynaecology.</p>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6 wthree-sb1 sb2">
                <span class="fa fa-certificate sicon" aria-hidden="true"></span>
                <span class="num">03</span><h4>Paediatrics</h4>
                <p>We provide the most essential health values with the best of Paediatrics.</p>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6 wthree-sb1">
                <span class="fa fa-heartbeat sicon" aria-hidden="true"></span>
                <span class="num">04</span><h4>Cardiac Center</h4>
                <p>We provide the most essential health values with the best of Cardian Health Care.</p>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>

























































































































































































































































































































































































































<script src="js/imgloaded.pkgd.min.js"></script>
<script src="js/masonry.pkgd.min.js"></script>
<script src="js/classie.js"></script>
<script src="js/cbpGridGallery.js"></script>
<script>
    new CBPGridGallery(document.getElementById('grid-gallery'));
</script>
<!-- //laboratory-section -->
<!-- team -->
<div class="team w3ls-section" id="team">
    <div class="container">
        <div class="w3-agileits-team-title">
            <h3 class="h3-w3l">our amazing team</h3>
            <div id="horizontalTab">
                <div class="resp-tabs-container">
                    <ul class="col-md-6 col-sm-6 resp-tabs-list">
                        <li>
                            <img src="<?php echo e(asset('img/small.png')); ?>" alt=" " class="img-responsive"/>
                        </li>
                        <li>
                            <img src="<?php echo e(asset('img/small.png')); ?>" alt=" " class="img-responsive"/>
                        </li>
                        <li>
                            <img src="<?php echo e(asset('img/small.png')); ?>" alt=" " class="img-responsive"/>
                        </li>
                        <li>
                            <img src="<?php echo e(asset('img/small.png')); ?>" alt=" " class="img-responsive"/>
                        </li>
                    </ul>
                    <div class="tab1">
                        <div class="col-md-6 col-sm-6 team-Info-agileits">
                            <h4>Dr.Ibukun </h4>
                            <span>Neurologist</span>
                            <p>As a Neurologist, I give my best to ensure optimum patient medical care and stability.</p>

                        </div>

                        <div class="col-md-6 col-sm-6 team-img-w3-agile"></div>
                        <div class="clearfix"></div>
                    </div>

                    <div class="tab2">
                        <div class="col-md-6 col-sm-6 team-Info-agileits">
                            <h4>Dr.Awoleke</h4>
                            <span>cardiologist</span>
                            <p>Service to mankind in the aspect of health is the most fulfiling duty I know. And as a
                                Cardiologist, I ... .</p>

                        </div>
                        <div class="col-md-6 col-sm-6 team-img-w3-agile"></div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="tab3">
                        <div class="col-md-6 col-sm-6 team-Info-agileits">
                            <h4>Dr.Kolade</h4>
                            <span>psychiatrist</span>
                            <p>Service to mankind in the aspect of health is the most fulfiling duty I know. And as a
                                Cardiologist, I ... .</p>

                        </div>
                        <div class="col-md-6 col-sm-6 team-img-w3-agile"></div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="tab4">
                        <div class="col-md-6 col-sm-6 team-Info-agileits">
                            <h4>Dr.Jude</h4>
                            <span>dermatologist</span>
                            <p>Service to mankind in the aspect of health is the most fulfiling duty I know. And as a
                                Cardiologist, I ... .</p>
                        </div>
                        <div class="col-md-6 col-sm-6 team-img-w3-agile"></div>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="clearfix"></div>

            </div>
        </div>
    </div>
</div>
<!-- //team -->

<!-- Appointment -->
<div class=" w3_agileits-apt">
    <div class="container">
        <div class="agile-caption">
            <div class="book-appointment">
                <p>Choose Good Health For Yourself And Your Family.
                    <a href="#" data-toggle="modal" data-target="#myModal1"><span class="appoint">
                        Book An Appointment Now</span></a></p>
            </div>
        </div>
    </div>
</div>
<!-- //Appointment -->
<!-- modal -->
<div class="modal about-modal fade" id="myModal1" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                <h5>appointment booking</h5>
            </div>
            <div class="modal-body">
                <div class="wthree-info">
                    <h3>Fill details below to book an appointment</h3>
                    <div class="login">
                        <form action="#" method="post">
                            <input type="text" class="user" name="first_name" placeholder="First Name" required="">
                            <input type="text" class="user" name="last_name" placeholder="Last Name" required="">
                            <input type="text" class="user" name="email" placeholder="Email" required="">
                            <input type="text" name="phone" placeholder="Phone" required="">
                            <input placeholder="Date" class="date" id="datepicker" type="text" value=""
                                   onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}"
                                   required=""/>
                            <select required="">
                                <option value="">Select Time</option>
                                <option value="1">08:00-8:30</option>
                                <option value="2">08:30-9:00</option>
                                <option value="3"> 09:00-9:30</option>
                                <option value="4">09:30-10:00</option>
                            </select>
                            <textarea type="text" placeholder="Your message..."></textarea>

                            <input class="appoint" type="submit" value="request appointment">
                        </form>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<!-- //modal -->

<!-- contact -->








































<!-- //contact -->
<!-- footer-->
<div class="agileits_w3layouts-footer">
    <div class="copy-right text-center">
        <p>&copy; 2018 Dominion Medical Center. All rights reserved</p>
    </div>
</div>
<!-- footer-->
<script src="<?php echo e(asset('js/jarallax.js')); ?>"></script>
<script src="<?php echo e(asset('js/SmoothScroll.min.js')); ?>"></script>
<script type="text/javascript">
    /* init Jarallax */
    $('.jarallax').jarallax({
        speed: 0.5,
        imgWidth: 1366,
        imgHeight: 768
    })
</script>
<!-- here starts scrolling icon -->
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="<?php echo e(asset('js/move-top.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/easing.js')); ?>"></script>
<script type="text/javascript">
    jQuery(document).ready(function ($) {
        $(".scroll").click(function (event) {
            event.preventDefault();
            $('html,body').animate({scrollTop: $(this.hash).offset().top}, 1000);
        });
    });
</script>
<!-- /ends-smoth-scrolling -->
<!-- //here ends scrolling icon -->
<!--start-date-piker-->
<link rel="stylesheet" href="<?php echo e(asset('css/jquery-ui.css')); ?>"/>
<script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>
<script>
    $(function () {
        $("#datepicker,#datepicker1").datepicker();
    });
</script>
<!-- //End-date-piker -->
<!-- here starts scrolling icon -->
<script type="text/javascript">
    $(document).ready(function () {
        /*
         var defaults = {
         containerID: 'toTop', // fading element id
         containerHoverID: 'toTopHover', // fading element hover id
         scrollSpeed: 1200,
         easingType: 'linear'
         };
         */

        $().UItoTop({easingType: 'easeOutQuart'});

    });
</script>
<!--tabs-->
<script src="<?php echo e(asset('js/easy-responsive-tabs.js')); ?>"></script>
<script>
    $(document).ready(function () {
        $('#horizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true,   // 100% fit in a container
            closed: 'accordion', // Start closed if in accordion view
            activate: function (event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#tabInfo');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });
        $('#verticalTab').easyResponsiveTabs({
            type: 'vertical',
            width: 'auto',
            fit: true
        });
    });
</script>
<!--//tabs-->
</body>
</html>