<!-- Page Header-->
<header class="page-header">
    <div class="container-fluid">
        <h2 class="no-margin-bottom"><?php echo e(isset($page->title) ? $page->title : "Dashboard"); ?></h2>
    </div>
</header>