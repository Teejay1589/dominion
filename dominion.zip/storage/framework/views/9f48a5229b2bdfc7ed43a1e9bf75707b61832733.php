<div class="table-wrapper">
	<table class="table table-hover">
		<thead>
			<tr>
				<th>#</th>
				<th>Title</th>
                <th>Patient</th>
                <th>Symptoms</th>
                <th>Treatment</th>
                <th>Medicine</th>
                <th>Is Consultation</th>
                <th>Is Emergency</th>
                <th>Is Delivery</th>
                <th>Delivery Success</th>
                <th>Doctors</th>
                <th>Surgeries</th>
                <th>Disharged on</th>
				<th>Actions</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    			<tr>
    				<td><?php echo e($loop->iteration); ?></td>
    				<td><?php echo e($element->title); ?></td>
                    <td><?php echo e($element->patient->first_name.' '.$element->patient->last_name); ?></td>
                    <td><?php echo e(str_limit($element->symptoms, 50)); ?></td>
                    <td><?php echo e(str_limit($element->treatment, 50)); ?></td>
                    <td><?php echo e(str_limit($element->medicine, 50)); ?></td>
                    <td><?php echo e(($element->is_consultation) ? 'YES' : 'NO'); ?></td>
                    <td><?php echo e(($element->is_emergency) ? 'YES' : 'NO'); ?></td>
                    <td><?php echo e(($element->is_delivery) ? 'YES' : 'NO'); ?></td>
                    <td><?php echo e(($element->is_success) ? 'YES' : 'NO'); ?></td>
                    <td><?php echo e(isset($element->case_doctors) ? $element->case_doctors->count() : 0); ?></td>
                    <td><?php echo e(isset($element->surgeries) ? $element->surgeries->count() : 0); ?></td>
                    <td><span title="<?php echo e(is_null($element->discharged_on) ? '' : Carbon::createFromFormat('Y-m-d H:i:s', $element->discharged_on)->toFormattedDateString()); ?>"><?php echo e(is_null($element->discharged_on) ? '' : Carbon::createFromFormat('Y-m-d H:i:s', $element->discharged_on)->format('Y-m-d')); ?></span></td>
    				<td>
    					<small>
                            <a href="#modal-view-<?php echo e($element->id); ?>" data-toggle="modal">view</a>
                            <a href="#modal-update-<?php echo e($element->id); ?>" data-toggle="modal">update</a>
    						<a href="<?php echo e(url('/m/cases/delete/'.$element->id)); ?>" class="text-danger confirm-action">delete</a>
    					</small>
                        <?php echo $__env->make('partials.case-view', ['active_object' => $element], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo $__env->make('forms.cases-update', ['active_object' => $element], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    				</td>
    			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<?php if(count($cases) == 0): ?>
        <p class="text-center text-danger">No Cases Yet!</p>
	<?php endif; ?>
</div>