<form action="<?php echo e(url('/m/cases/create')); ?>" method="post">
	<div class="modal fade" id="modal-create">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Create Case Form</h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
						<span class="sr-only">Close</span>
					</button>
				</div>
				<div class="modal-body">
					<?php echo e(csrf_field()); ?>


					

					<div class="form-group">
						<label class="form-control-label">Title <span class="text-danger">*</span></label>
						<input class="form-control" type="text" name="title" placeholder="Title" value="<?php echo e(old('title')); ?>" required>
					</div>

                    <div class="row">
                        <div class="col-lg-6 col-xs-12">
                            <div class="form-group">
                            	<label class="form-control-label">Select Patient <span class="text-danger">*</span></label>
								<select class="form-control" name="patient" required>
									<?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($element->id); ?>" <?php echo e((old('patient') == $element->id) ? 'selected' : ''); ?>><?php echo e($element->first_name.' '.$element->last_name); ?> [<?php echo e($element->phone); ?>]</option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>
                        </div>
                        <div class="col-lg-6 col-xs-12">
                            <div class="form-group">
                                <label class="form-control-label">Doctors <span class="text-danger">*</span></label>
								<select class="select-doctors" name="doctors[]" required multiple>
									<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($element->id); ?>" <?php echo e(in_array($element->id, old('doctors', array())) ? 'selected' : ''); ?>><?php echo e($element->full_name()); ?> [<?php echo e($element->role->name); ?>]</option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>
                        </div>
                    </div>

					<div class="form-group">
						<label class="form-control-label">Symptoms </label>
						<textarea name="symptoms" class="form-control" rows="2" placeholder="Symptoms"><?php echo e(old('symptoms')); ?></textarea>
					</div>

                    <div class="row">
                        <div class="col-lg-6 col-xs-12">
                            <div class="form-group">
                            	<label class="form-control-label">Treatment </label>
								<textarea name="treatment" class="form-control" rows="3" placeholder="Treatment"><?php echo e(old('treatment')); ?></textarea>
                            </div>
                        </div>
                        <div class="col-lg-6 col-xs-12">
                            <div class="form-group">
                                <label class="form-control-label">Medicine </label>
								<textarea name="medicine" class="form-control" rows="3" placeholder="Medicine"><?php echo e(old('medicine')); ?></textarea>
                            </div>
                        </div>
                    </div>

					<div class="form-group">
						<label class="form-control-label form-check form-check-inline">
							<input type="checkbox" name="is_consultation" class="form-check-input" value="1" <?php echo e(old('is_consultation') == 1 ? 'checked' : ''); ?>> Is Consultation
						</label>
						<label class="form-control-label form-check form-check-inline">
							<input type="checkbox" name="is_emergency" class="form-check-input" value="1" <?php echo e(old('is_emergency') == 1 ? 'checked' : ''); ?>> is Emergency
						</label>
						<label class="form-control-label form-check form-check-inline">
							<input type="checkbox" name="is_delivery" class="form-check-input" value="1" <?php echo e(old('is_delivery') == 1 ? 'checked' : ''); ?>> is Delivery
						</label>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary">Create</button>
				</div>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
</form>