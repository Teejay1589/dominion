<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo e(env('APP_NAME', 'APP NAME')); ?> is a Hospital Management System">
    <meta name="author" content="Yinka, Tunji Oyeniran">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(env('APP_NAME', 'APP NAME')); ?></title>

    <!-- Styles -->
    
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('vendor/font-awesome/css/font-awesome.min.css')); ?>">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="<?php echo e(asset('css/fontastic.css')); ?>">
    <!-- Google fonts - Poppins -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.default.css')); ?>" id="theme-stylesheet">

    
    <?php if( View::hasSection('page_styles') ): ?>
        <?php echo $__env->yieldContent('page_styles'); ?>
    <?php endif; ?>

    
    <style type="text/css">
        .table-wrapper {
          overflow-x: auto;
        }
        textarea {
          resize: vertical;
        }
        .modal.in {
            /*background: dimgray;*/
        }
        .card-title {
            margin-bottom: .5rem;
        }
    </style>
</head>
<body>
    <div id="app">
        <div id="app" class="page">
            <?php if(auth()->guard()->check()): ?>
                <?php echo $__env->make('shared.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('shared.navbar-patient', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="page-content d-flex align-items-stretch">
                    <?php echo $__env->make('shared.sidebar-patient', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <div class="content-inner">
                        <?php echo $__env->make('shared.page-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <?php echo $__env->yieldContent('content'); ?>

                        <?php echo $__env->make('shared.page-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
                <?php echo $__env->yieldContent('content'); ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

    <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/popper.js/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/jquery.cookie/jquery.cookie.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/jquery-validation/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/charts-home.js')); ?>"></script>
    <!-- Main File-->
    <script src="<?php echo e(asset('js/front.js')); ?>"></script>

    
    <script type="text/javascript">
      // Confirm Action
      $('.confirm-action').click(function(e) {
        var ans = confirm('Are you sureee?');
        if(ans) {
        } else {
          e.preventDefault();
        }
      });
    </script>

    
    <?php if( View::hasSection('page_scripts') ): ?>
        <?php echo $__env->yieldContent('page_scripts'); ?>
    <?php endif; ?>
</body>
</html>
