<div class="table-wrapper">
	<table class="table table-hover">
		<thead>
			<tr>
				<th>#</th>
				<th>Case Title</th>
				<th>Surgery Name</th>
                <th>Started At</th>
                <th>Ended At</th>
                <th>Is Successful</th>
				<th>Actions</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $surgeries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    			<tr>
    				<td><?php echo e($loop->iteration); ?></td>
    				<td><?php echo e($element->case->title); ?></td>
                    <td><?php echo e($element->name); ?></td>
                    <td><span title="<?php echo e(is_null($element->started_at) ? '' : Carbon::createFromFormat('Y-m-d H:i:s', $element->started_at)->toFormattedDateString()); ?>"><?php echo e(is_null($element->started_at) ? '' : Carbon::createFromFormat('Y-m-d H:i:s', $element->started_at)->format('Y-m-d')); ?></span></td>
                    <td><span title="<?php echo e(is_null($element->ended_at) ? '' : Carbon::createFromFormat('Y-m-d H:i:s', $element->ended_at)->toFormattedDateString()); ?>"><?php echo e(is_null($element->ended_at) ? '' : Carbon::createFromFormat('Y-m-d H:i:s', $element->ended_at)->format('Y-m-d')); ?></span></td>
                    <td><?php echo e(($element->is_success) ? 'YES' : 'NO'); ?></td>
    				<td>
    					<small>
                            <a href="#modal-view-<?php echo e($element->id); ?>" data-toggle="modal">view</a>
                            <a href="#modal-update-<?php echo e($element->id); ?>" data-toggle="modal">update</a>
    						<a href="<?php echo e(url('/m/surgeries/delete/'.$element->id)); ?>" class="text-danger confirm-action">delete</a>
    					</small>
                        <?php echo $__env->make('partials.surgery-view', ['active_object' => $element], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo $__env->make('forms.surgeries-update', ['active_object' => $element], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    				</td>
    			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<?php if(count($surgeries) == 0): ?>
        <p class="text-center text-danger">No Surgeries Yet!</p>
	<?php endif; ?>
</div>