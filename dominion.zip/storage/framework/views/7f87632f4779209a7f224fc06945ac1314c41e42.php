<div class="table-wrapper">
	<table class="table table-hover">
		<thead>
			<tr>
				<th>#</th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Gender</th>
				<th>Phone Number</th>
				<th>Next of Kin</th>
				<th>Blood Group</th>
				<th>Weight</th>
				<th>Height</th>
				<th>No of Cases</th>
				<th>Actions</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    			<tr>
    				<td><?php echo e($loop->iteration); ?></td>
    				<td><?php echo e($element->first_name); ?></td>
    				<td><?php echo e($element->last_name); ?></td>
    				<td><?php echo e($element->gender); ?></td>
    				<td><?php echo e($element->phone); ?></td>
    				<td><?php echo e($element->next_of_kin); ?> <?php echo e((isset($element->next_of_kin_telephone)) ? "[".$element->next_of_kin_telephone."]" : ""); ?></td>
    				<td><?php echo e($element->blood_group); ?></td>
    				<td><?php echo e($element->weight); ?></td>
    				<td><?php echo e($element->height); ?></td>
    				<td><?php echo e($element->cases->count()); ?> <small><a href="javascript:;">cases</a></small></td>
    				<td>
    					<small>
                            <a href="#modal-view-<?php echo e($element->id); ?>" data-toggle="modal">view</a>
                            <a href="#modal-update-<?php echo e($element->id); ?>" data-toggle="modal">update</a>
    						<a href="<?php echo e(url('/m/patients/delete/'.$element->id)); ?>" class="text-danger confirm-action">delete</a>
    					</small>
    					<?php echo $__env->make('partials.patient-view', ['active_object' => $element], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    					<?php echo $__env->make('forms.patients-update', ['active_object' => $element], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    				</td>
    			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<?php if(count($patients) == 0): ?>
        <p class="text-center text-danger">No Patients Yet!</p>
	<?php endif; ?>
</div>